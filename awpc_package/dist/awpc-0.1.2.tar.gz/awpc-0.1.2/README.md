
# AWPC - AmundWorks Python Collective

Engineering & Math Toolkit

## Install
```shell
pip install awpc
```

## Example
```python
import awpc
print(awpc.FibonacciList(10))
```